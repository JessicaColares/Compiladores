int main(){
    int a, b, c;
}