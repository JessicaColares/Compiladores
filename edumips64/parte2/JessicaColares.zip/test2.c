int atualiza() {
    int y;
    y = 10;
    y *= 2; 
    return y;
}

int main(){
    atualiza();    

    return 0;
}