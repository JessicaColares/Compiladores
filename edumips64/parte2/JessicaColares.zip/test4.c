int multiplica(int a, int b) {
    int resultado;
    resultado = a * b;
    return resultado;
}

int main() {
    multiplica(10, 5);
    return 0;
}
