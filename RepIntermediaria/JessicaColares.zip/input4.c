int main() {
    int x = 1;
    int y = 0;
    if (x && !y) {
        return 1;
    } else {
        return 0;
    }
}