int main() {
    int x = 5;
    int y;
    y = x + 3;
    return y;
}