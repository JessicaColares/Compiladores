int main() {
    int a = 10;
    int b = 20;
    if (a < b) {
        a = a + 1;
    } else {
        b = b - 1;
    }
    return a;
}