int main() {
    int i = 0;
    while (i < 5) {
        i = i + 1;
    }
    return i;
}